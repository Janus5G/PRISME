from __future__ import annotations

import numpy as np
import pytest

from optical_router.compiler import (
    MappingTable,
    compile_color_matrix,
    inspect_binary,
    simulate_stream_timing,
)
from optical_router.errors import PhysicsDomainError

MAPPING = MappingTable(
    (.405, .532, .650, .780),
    (0, 45, 90, 135),
    (.125, .375, .625, .875),
)


def matrices():
    return (
        np.array([[.405, .532], [.650, .780]]),
        np.array([[0, 45], [90, 135]], dtype=float),
        np.array([[.125, .375], [.625, .875]]),
    )


def test_binary_deterministic_and_self_describing() -> None:
    first = compile_color_matrix(*matrices(), MAPPING)
    second = compile_color_matrix(*matrices(), MAPPING)
    decoded = inspect_binary(first.content)
    assert first.content == second.content
    assert first.bits_per_symbol == 6
    assert first.payload_bytes == 3
    assert decoded["rows"] == 2
    assert decoded["columns"] == 2
    assert decoded["symbol_count"] == 4
    assert decoded["mapping"]["wavelength_bins_um"] == pytest.approx(
        list(MAPPING.wavelength_bins_um)
    )


def test_crc_corruption_detected() -> None:
    compiled = compile_color_matrix(*matrices(), MAPPING)
    corrupted = compiled.content[:-1] + bytes([compiled.content[-1] ^ 1])
    with pytest.raises(PhysicsDomainError) as error:
        inspect_binary(corrupted)
    assert error.value.code == "CRC_MISMATCH"


def test_quantization_tolerance() -> None:
    wavelengths, polarizations, intensities = matrices()
    wavelengths[0, 0] = .430
    with pytest.raises(PhysicsDomainError) as error:
        compile_color_matrix(wavelengths, polarizations, intensities, MAPPING)
    assert error.value.code == "WAVELENGTH_QUANTIZATION_ERROR"


def test_timing_separates_flight_and_conversion() -> None:
    wavelengths, _, _ = matrices()
    timing = simulate_stream_timing(
        wavelengths_um=wavelengths,
        symbol_count=1_000_000,
        payload_bytes=1_000_000,
        fiber_length_m=100,
        free_space_distance_m=1,
        sensor_sample_rate_gsps=20,
        sensor_channels=64,
        memory_bandwidth_gbps=160,
    )
    assert timing.propagation_latency_ns > 400
    assert timing.dispersion_skew_ps > 0
    assert timing.total_pipeline_latency_ns > timing.propagation_latency_ns


@pytest.mark.parametrize(
    "mutator",
    [
        lambda w, p, i: (w.reshape(4), p, i),
        lambda w, p, i: (w, p, np.full_like(i, 2.0)),
        lambda w, p, i: (w, np.full_like(p, 180.0), i),
    ],
)
def test_invalid_matrices(mutator) -> None:
    with pytest.raises(PhysicsDomainError):
        compile_color_matrix(*mutator(*matrices()), MAPPING)


def test_truncated_binary() -> None:
    with pytest.raises(PhysicsDomainError):
        inspect_binary(b"OPTB")

