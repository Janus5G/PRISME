from __future__ import annotations

from fastapi.testclient import TestClient

from optical_router.api import create_app
from optical_router.compiler import inspect_binary

client = TestClient(create_app())


def write_body(**overrides):
    body = {
        "data_size_bytes": 1_048_576,
        "numerical_aperture": .55,
        "focal_depth_mm": .5,
        "wavelength_um": .8,
        "pulse_energy_nj": 500,
        "temperature_k": 303,
    }
    body.update(overrides)
    return body


def test_health_and_dashboard() -> None:
    assert client.get("/health").json()["status"] == "ok"
    dashboard = client.get("/")
    assert dashboard.status_code == 200
    assert "Optical Routing Simulator" in dashboard.text


def test_write_endpoint_and_uv_error() -> None:
    response = client.post("/simulate/write", json=write_body())
    assert response.status_code == 200
    assert response.json()["physical_valid"] is True
    assert 77 < response.json()["voxel"]["spherical_aberration_stretch_um"] < 80
    uv = client.post("/simulate/write", json=write_body(wavelength_um=.19))
    assert uv.status_code == 422
    assert uv.json()["error"]["code"] == "UV_ABSORPTION_EDGE"


def test_stream_download() -> None:
    matrix = [
        [
            {"wavelength_um": .405, "polarization_deg": 0, "intensity": .125},
            {"wavelength_um": .532, "polarization_deg": 45, "intensity": .375},
        ],
        [
            {"wavelength_um": .650, "polarization_deg": 90, "intensity": .625},
            {"wavelength_um": .780, "polarization_deg": 135, "intensity": .875},
        ],
    ]
    response = client.post(
        "/simulate/stream", json={"matrix": matrix, "output_filename": "test.bin"}
    )
    assert response.status_code == 200
    assert response.headers["content-type"] == "application/octet-stream"
    assert response.headers["x-optical-symbols"] == "4"
    assert inspect_binary(response.content)["symbol_count"] == 4


def test_schema_rejects_extra_fields() -> None:
    response = client.post("/simulate/write", json=write_body(extra=1))
    assert response.status_code == 422
    assert response.json()["error"]["code"] == "REQUEST_VALIDATION_ERROR"

