from __future__ import annotations

import numpy as np
import pytest

from optical_router.errors import PhysicsDomainError
from optical_router.physics import (
    arrhenius_retention,
    sellmeier_group_index,
    sellmeier_index,
    simulate_write,
    spherical_aberration,
)


def test_reference_index_and_vectorization() -> None:
    assert float(sellmeier_index(0.5893)) == pytest.approx(1.4584, abs=5e-5)
    assert float(sellmeier_group_index(0.5893)) > float(sellmeier_index(0.5893))
    vector = sellmeier_index(np.array([0.405, 0.800, 1.550]))
    assert vector.shape == (3,)
    assert np.all(np.diff(vector) < 0)


@pytest.mark.parametrize(
    ("wavelength", "code"),
    [(0.20999, "UV_ABSORPTION_EDGE"), (6.7001, "SELLMEIER_OUT_OF_RANGE")],
)
def test_spectral_boundaries(wavelength: float, code: str) -> None:
    with pytest.raises(PhysicsDomainError) as error:
        sellmeier_index(wavelength)
    assert error.value.code == code


def test_arrhenius_303_k_extrapolation() -> None:
    result = arrhenius_retention(303)
    assert result.log10_years == pytest.approx(20.476, abs=.01)
    assert result.uncertainty_orders == pytest.approx(1.164, abs=.01)
    assert result.lifetime_years == pytest.approx(3e20, rel=.08)


def test_aberration_calibration() -> None:
    result = spherical_aberration(.8, .55, .5)
    assert result.geometry.spherical_aberration_stretch_um == pytest.approx(78.7, abs=1)
    assert result.geometry.axial_fwhm_um > 78.7
    assert 0 < result.axial_energy_density_ratio < 1


def test_threshold_switches_regime() -> None:
    base = dict(
        data_size_bytes=1024,
        numerical_aperture=.55,
        focal_depth_mm=.5,
        wavelength_um=.8,
        pulse_duration_fs=300,
        temperature_k=303,
    )
    strong = simulate_write(pulse_energy_nj=500, **base)
    weak = simulate_write(pulse_energy_nj=100, **base)
    assert strong["physical_valid"] is True
    assert strong["retention"]["retention_class"] == "type_ii_nanograting"
    assert weak["physical_valid"] is False
    assert weak["retention"]["lifetime_years"] == 30


def test_invalid_physics_parameters() -> None:
    with pytest.raises(PhysicsDomainError):
        arrhenius_retention(0)
    with pytest.raises(PhysicsDomainError):
        spherical_aberration(.8, 1.0, .5)
    with pytest.raises(PhysicsDomainError):
        spherical_aberration(.8, .55, -1)

