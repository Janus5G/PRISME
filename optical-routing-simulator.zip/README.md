# Optical Routing Simulator

Production-oriented localhost service for fused-silica write validation and
direct spectral-state compilation to a compact `.bin` stream.

## Architecture

- `physics.py` — vectorized Malitson dispersion, analytical group index,
  Arrhenius retention, planar-interface spherical aberration, voxel geometry,
  and Type I/II threshold classification.
- `compiler.py` — vectorized nearest-channel quantization, dense NumPy bit
  packing, self-describing OPTB v1 serialization, CRC32, and link timing.
- `api.py` — strict FastAPI contracts, bounded requests, machine-readable
  errors, binary downloads, OpenAPI docs, and the local dashboard.

## Launch

Python 3.11+:

```bash
python3 -m venv .venv
source .venv/bin/activate
python3 -m pip install -e ".[dev]"
python3 -m optical_router --reload
```

Open [http://127.0.0.1:8000](http://127.0.0.1:8000). Interactive API docs are
at [http://127.0.0.1:8000/docs](http://127.0.0.1:8000/docs).

Verify:

```bash
pytest
```

Container:

```bash
docker build -t optical-routing-simulator .
docker run --rm -p 8000:8000 optical-routing-simulator
```

## Endpoints

### `POST /simulate/write`

```bash
curl -sS http://127.0.0.1:8000/simulate/write \
  -H 'content-type: application/json' \
  --data @examples/write-request.json
```

Returns physical validity, write regime, phase/group indices, group velocity,
retention exponent and error bounds, aberration-adjusted intensity, voxel
geometry, and an idealized write plan. Wavelengths below `0.21 µm` hard-fail
with `UV_ABSORPTION_EDGE`; wavelengths above `6.7 µm` fail with
`SELLMEIER_OUT_OF_RANGE`.

### `POST /simulate/stream`

```bash
curl -sS http://127.0.0.1:8000/simulate/stream \
  -H 'content-type: application/json' \
  --data @examples/stream-request.json \
  --output optical-stream.bin \
  --dump-header -
```

The response body is the binary. `X-Optical-*` headers report symbol count,
packing density, CRC32, propagation delay, dispersion skew, conversion delay,
throughput, and the simulated pipeline bottleneck.

## Mathematical contract

For wavelength \(\lambda\) in micrometres:

\[
n^2(\lambda)=1+\sum_{i=1}^{3}\frac{B_i\lambda^2}{\lambda^2-C_i}
\]

| \(i\) | \(B_i\) | \(C_i\) (µm²) |
| --- | ---: | ---: |
| 1 | 0.6961663 | \(0.0684043^2\) |
| 2 | 0.4079426 | \(0.1162414^2\) |
| 3 | 0.8974794 | \(9.896161^2\) |

The analytical derivative gives \(n_g=n-\lambda\,dn/d\lambda\). Malitson's
original fit covered 0.21–3.71 µm at 20 °C; later infrared validation is the
basis for the commonly used 6.7 µm upper range.

Type II retention:

\[
\tau(T)=\frac{1}{\nu}\exp\left(\frac{E_a}{k_BT}\right)
\]

with \(E_a=1.81\pm0.07\) eV and \(\nu=135\) Hz. At 303 K this gives
\(10^{20.48}\) years with ±1.16 orders of magnitude from activation-energy
uncertainty alone. This is an accelerated-aging extrapolation, not a direct
aeon-scale measurement.

The planar air–silica interface approximation is:

\[
\Delta z=d\left[
\frac{\tan(\arcsin(\mathrm{NA}))}
{\tan(\arcsin(\mathrm{NA}/n))}-n
\right]
\]

At 0.8 µm, 0.5 mm, and NA 0.55, it yields 78.7 µm longitudinal stretch.
Diffraction and geometric stretch combine in quadrature. The effective
intensity multiplier is the ratio of diffraction axial FWHM to that combined
envelope.

The default 10 TW/cm² Type II threshold is an explicit engineering setting,
not a universal silica constant. If missed, the requested "decades" behavior
uses a transparent 30-year Type I policy with ±0.5 orders of magnitude.

## OPTB v1

All fixed integers are little-endian; packed symbols are MSB-first.

| Region | Contents |
| --- | --- |
| Fixed header | `OPTB`, version, flags, dimensions, symbol count, bit widths, mapping counts, payload size, CRC32 |
| Mapping table | `float32` wavelength, polarization, and intensity bins |
| Payload | packed `[wavelength index | polarization index | intensity index]` symbols |

The default 8 × 4 × 4 mapping uses 7 bits per optical state. `inspect_binary()`
checks magic, version, lengths, mapping size, and CRC32.

## Scope and limitations

- Scalar engineering model, not a Debye/Richards–Wolf or full-wave solver.
- No nonlinear propagation, self-focusing, plasma dynamics, noise, BER, FEC,
  scattering, or modal coupling.
- Index is referenced to 20 °C; the Arrhenius temperature does not alter it.
- Optical propagation uses silica group velocity. Electronic conversion is
  never claimed to occur at the speed of light.
- Write time excludes stage motion, SLM refresh, retries, and verification.
- Calibrate thresholds, objective transmission, sensor response, and pulse
  shape against real hardware before making design decisions.

## Literature basis

- I. H. Malitson, “Interspecimen Comparison of the Refractive Index of Fused
  Silica,” *JOSA* 55 (1965),
  [doi:10.1364/JOSA.55.001205](https://doi.org/10.1364/JOSA.55.001205).
- J. Zhang et al., “Seemingly Unlimited Lifetime Data Storage in Nanostructured
  Glass,” *PRL* 112 (2014),
  [doi:10.1103/PhysRevLett.112.033901](https://doi.org/10.1103/PhysRevLett.112.033901).
- Q. Sun et al., “Effect of Spherical Aberration on the Propagation of a Tightly
  Focused Femtosecond Laser Pulse Inside Fused Silica,” *Journal of Optics A*
  7 (2005),
  [doi:10.1088/1464-4258/7/11/006](https://doi.org/10.1088/1464-4258/7/11/006).

