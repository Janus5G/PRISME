from __future__ import annotations

from dataclasses import asdict
import re

import numpy as np

from .compiler import MappingTable, compile_color_matrix, simulate_stream_timing
from .errors import PhysicsDomainError
from .models import StreamSimulationRequest, WriteSimulationRequest
from .physics import simulate_write

MAX_STREAM_SYMBOLS = 10_000_000


def run_write(request: WriteSimulationRequest) -> dict[str, object]:
    return simulate_write(**request.model_dump())


def run_stream(request: StreamSimulationRequest):
    rows, columns = len(request.matrix), len(request.matrix[0])
    count = rows * columns
    if count > MAX_STREAM_SYMBOLS:
        raise PhysicsDomainError(
            "STREAM_TOO_LARGE",
            f"Stream has {count:,} states; maximum is {MAX_STREAM_SYMBOLS:,}.",
        )
    triples = np.fromiter(
        (
            value
            for row in request.matrix
            for state in row
            for value in (state.wavelength_um, state.polarization_deg, state.intensity)
        ),
        dtype=np.float64,
        count=count * 3,
    ).reshape(rows, columns, 3)
    mapping = MappingTable(
        tuple(request.mapping.wavelength_bins_um),
        tuple(request.mapping.polarization_bins_deg),
        tuple(request.mapping.intensity_bins),
        request.mapping.max_wavelength_error_nm,
    )
    compiled = compile_color_matrix(
        triples[..., 0], triples[..., 1], triples[..., 2], mapping
    )
    timing = simulate_stream_timing(
        wavelengths_um=triples[..., 0],
        symbol_count=compiled.symbol_count,
        payload_bytes=compiled.payload_bytes,
        fiber_length_m=request.fiber_length_m,
        free_space_distance_m=request.free_space_distance_m,
        sensor_sample_rate_gsps=request.sensor_sample_rate_gsps,
        sensor_channels=request.sensor_channels,
        memory_bandwidth_gbps=request.memory_bandwidth_gbps,
    )
    return compiled, timing


def safe_filename(filename: str) -> str:
    sanitized = re.sub(r"[^A-Za-z0-9._-]", "_", filename).strip("._")
    if not sanitized:
        sanitized = "optical-stream"
    return sanitized if sanitized.lower().endswith(".bin") else sanitized + ".bin"


def metadata(compiled, timing) -> dict[str, object]:
    return {
        "symbol_count": compiled.symbol_count,
        "bits_per_symbol": compiled.bits_per_symbol,
        "payload_bytes": compiled.payload_bytes,
        "crc32": f"{compiled.crc32:08x}",
        "shape": [compiled.rows, compiled.columns],
        "quantization": compiled.quantization,
        "timing": asdict(timing),
    }

