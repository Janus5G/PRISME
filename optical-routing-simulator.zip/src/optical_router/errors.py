from __future__ import annotations


class PhysicsDomainError(ValueError):
    """A machine-readable error at a validated physics boundary."""

    def __init__(self, code: str, message: str, *, context: dict | None = None) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.context = context or {}

