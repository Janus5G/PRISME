from __future__ import annotations

import json
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse, Response
from starlette.middleware.trustedhost import TrustedHostMiddleware

from .errors import PhysicsDomainError
from .models import StreamSimulationRequest, WriteSimulationRequest
from .service import metadata, run_stream, run_write, safe_filename

STATIC_DIR = Path(__file__).parent / "static"
MAX_BODY_BYTES = 64 * 1024 * 1024


def create_app() -> FastAPI:
    app = FastAPI(
        title="Optical Routing Simulator",
        version="0.1.0",
        description="Fused-silica write simulation and spectral-state binary compilation.",
    )
    app.add_middleware(
        TrustedHostMiddleware,
        allowed_hosts=["localhost", "127.0.0.1", "::1", "testserver"],
    )
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["http://localhost:3000", "http://127.0.0.1:3000"],
        allow_methods=["GET", "POST"],
        allow_headers=["Content-Type"],
        expose_headers=["X-Optical-Metadata", "X-CRC32"],
    )

    @app.middleware("http")
    async def body_limit(request: Request, call_next):
        length = request.headers.get("content-length")
        if length and int(length) > MAX_BODY_BYTES:
            return JSONResponse(
                status_code=413,
                content={"error": {"code": "REQUEST_TOO_LARGE", "message": "Request body exceeds 64 MiB."}},
            )
        return await call_next(request)

    @app.exception_handler(PhysicsDomainError)
    async def physics_error(_request: Request, exc: PhysicsDomainError):
        return JSONResponse(
            status_code=422,
            content={"error": {"code": exc.code, "message": exc.message, "context": exc.context}},
        )

    @app.exception_handler(RequestValidationError)
    async def validation_error(_request: Request, exc: RequestValidationError):
        return JSONResponse(
            status_code=422,
            content={
                "error": {
                    "code": "REQUEST_VALIDATION_ERROR",
                    "message": "Request body failed schema validation.",
                    "details": json.loads(json.dumps(exc.errors(), default=str)),
                }
            },
        )

    @app.get("/", include_in_schema=False)
    async def dashboard():
        return FileResponse(STATIC_DIR / "index.html")

    @app.get("/prisme", include_in_schema=False)
    async def prisme_app():
        return FileResponse(STATIC_DIR / "prisme.html")

    @app.get("/health")
    async def health():
        return {"status": "ok", "service": "optical-routing-simulator"}

    @app.post("/simulate/write")
    async def simulate_write_endpoint(request: WriteSimulationRequest):
        return run_write(request)

    @app.post("/simulate/stream")
    async def simulate_stream_endpoint(request: StreamSimulationRequest):
        compiled, timing = run_stream(request)
        meta = metadata(compiled, timing)
        filename = safe_filename(request.output_filename)
        headers = {
            "Content-Disposition": f'attachment; filename="{filename}"',
            "X-Optical-Symbols": str(compiled.symbol_count),
            "X-Bits-Per-Symbol": str(compiled.bits_per_symbol),
            "X-Payload-Bytes": str(compiled.payload_bytes),
            "X-CRC32": f"{compiled.crc32:08x}",
            "X-Propagation-Latency-Ns": f"{timing.propagation_latency_ns:.9g}",
            "X-Dispersion-Skew-Ps": f"{timing.dispersion_skew_ps:.9g}",
            "X-Total-Pipeline-Latency-Ns": f"{timing.total_pipeline_latency_ns:.9g}",
            "X-Payload-Throughput-Gbps": f"{timing.payload_throughput_gbps:.9g}",
            "X-Pipeline-Bottleneck": timing.bottleneck,
            "X-Optical-Metadata": json.dumps(meta, separators=(",", ":")),
        }
        return Response(compiled.content, media_type="application/octet-stream", headers=headers)

    return app


app = create_app()

