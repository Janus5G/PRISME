"""Vectorized dispersion, Arrhenius retention, and interface aberration."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from math import ceil, log10
from typing import Any

import numpy as np
from numpy.typing import ArrayLike, NDArray

from .constants import (
    BOLTZMANN_EV_K,
    DEFAULT_REPETITION_RATE_HZ,
    DEFAULT_TYPE_I_RETENTION_YEARS,
    DEFAULT_TYPE_I_UNCERTAINTY_ORDERS,
    DEFAULT_TYPE_II_THRESHOLD_TW_CM2,
    SECONDS_PER_JULIAN_YEAR,
    SELLMEIER_B,
    SELLMEIER_C_UM2,
    SELLMEIER_MAX_UM,
    SELLMEIER_MIN_UM,
    SPEED_OF_LIGHT_M_S,
    TYPE_II_ACTIVATION_ENERGY_EV,
    TYPE_II_ACTIVATION_ENERGY_SIGMA_EV,
    TYPE_II_FREQUENCY_FACTOR_HZ,
)
from .errors import PhysicsDomainError

FloatArray = NDArray[np.float64]


def _wavelengths(wavelength_um: ArrayLike) -> FloatArray:
    values = np.asarray(wavelength_um, dtype=np.float64)
    if not np.all(np.isfinite(values)):
        raise PhysicsDomainError("NONFINITE_WAVELENGTH", "Wavelengths must be finite.")
    if np.any(values < SELLMEIER_MIN_UM):
        offending = float(np.min(values))
        raise PhysicsDomainError(
            "UV_ABSORPTION_EDGE",
            f"{offending:g} µm is below silica's {SELLMEIER_MIN_UM:g} µm UV boundary.",
            context={"minimum_wavelength_um": SELLMEIER_MIN_UM, "offending_wavelength_um": offending},
        )
    if np.any(values > SELLMEIER_MAX_UM):
        offending = float(np.max(values))
        raise PhysicsDomainError(
            "SELLMEIER_OUT_OF_RANGE",
            f"{offending:g} µm exceeds the validated {SELLMEIER_MAX_UM:g} µm range.",
            context={"maximum_wavelength_um": SELLMEIER_MAX_UM, "offending_wavelength_um": offending},
        )
    return values


def sellmeier_index(wavelength_um: ArrayLike) -> FloatArray:
    """Malitson fused-silica phase index at 20 °C."""

    wavelength = _wavelengths(wavelength_um)
    wavelength_sq = np.square(wavelength)[..., None]
    return np.sqrt(
        1.0 + np.sum(
            SELLMEIER_B * wavelength_sq / (wavelength_sq - SELLMEIER_C_UM2),
            axis=-1,
        )
    )


def sellmeier_group_index(wavelength_um: ArrayLike) -> FloatArray:
    """Group index n_g = n - λ dn/dλ, with an analytical derivative."""

    wavelength = _wavelengths(wavelength_um)
    index = sellmeier_index(wavelength)
    expanded = wavelength[..., None]
    derivative_n_squared = np.sum(
        -2.0
        * expanded
        * SELLMEIER_B
        * SELLMEIER_C_UM2
        / np.square(np.square(expanded) - SELLMEIER_C_UM2),
        axis=-1,
    )
    return index - wavelength * derivative_n_squared / (2.0 * index)


@dataclass(frozen=True, slots=True)
class RetentionEstimate:
    retention_class: str
    log10_years: float
    uncertainty_orders: float
    lower_log10_years: float
    upper_log10_years: float
    lifetime_years: float | None
    model: str


def arrhenius_retention(
    temperature_k: float,
    *,
    activation_energy_ev: float = TYPE_II_ACTIVATION_ENERGY_EV,
    activation_energy_sigma_ev: float = TYPE_II_ACTIVATION_ENERGY_SIGMA_EV,
    frequency_factor_hz: float = TYPE_II_FREQUENCY_FACTOR_HZ,
) -> RetentionEstimate:
    """Type II lifetime in log space, avoiding exponential overflow."""

    if not np.isfinite(temperature_k) or temperature_k <= 0:
        raise PhysicsDomainError("INVALID_TEMPERATURE", "Temperature must be above 0 K.")
    if activation_energy_ev <= 0 or frequency_factor_hz <= 0:
        raise PhysicsDomainError("INVALID_ARRHENIUS_PARAMETER", "Arrhenius inputs must be positive.")
    log_seconds = (
        activation_energy_ev / (BOLTZMANN_EV_K * temperature_k * np.log(10.0))
        - log10(frequency_factor_hz)
    )
    log_years = float(log_seconds - log10(SECONDS_PER_JULIAN_YEAR))
    uncertainty = float(
        activation_energy_sigma_ev / (BOLTZMANN_EV_K * temperature_k * np.log(10.0))
    )
    return RetentionEstimate(
        retention_class="type_ii_nanograting",
        log10_years=log_years,
        uncertainty_orders=uncertainty,
        lower_log10_years=log_years - uncertainty,
        upper_log10_years=log_years + uncertainty,
        lifetime_years=10.0**log_years if log_years < 308 else None,
        model="arrhenius_type_ii_extrapolation",
    )


def type_i_retention_policy() -> RetentionEstimate:
    log_years = log10(DEFAULT_TYPE_I_RETENTION_YEARS)
    return RetentionEstimate(
        retention_class="type_i_engineering_fallback",
        log10_years=log_years,
        uncertainty_orders=DEFAULT_TYPE_I_UNCERTAINTY_ORDERS,
        lower_log10_years=log_years - DEFAULT_TYPE_I_UNCERTAINTY_ORDERS,
        upper_log10_years=log_years + DEFAULT_TYPE_I_UNCERTAINTY_ORDERS,
        lifetime_years=DEFAULT_TYPE_I_RETENTION_YEARS,
        model="configurable_type_i_policy_not_arrhenius_measurement",
    )


@dataclass(frozen=True, slots=True)
class VoxelGeometry:
    lateral_fwhm_um: float
    diffraction_axial_fwhm_um: float
    spherical_aberration_stretch_um: float
    axial_fwhm_um: float
    aspect_ratio: float


@dataclass(frozen=True, slots=True)
class AberrationResult:
    index: float
    group_index: float
    group_velocity_m_s: float
    marginal_focus_factor: float
    axial_energy_density_ratio: float
    geometry: VoxelGeometry


def spherical_aberration(
    wavelength_um: float, numerical_aperture: float, focal_depth_mm: float
) -> AberrationResult:
    """Planar air–silica longitudinal spherical-aberration approximation."""

    if not 0.0 < numerical_aperture < 1.0:
        raise PhysicsDomainError("INVALID_NUMERICAL_APERTURE", "NA must be in (0, 1) in air.")
    if not np.isfinite(focal_depth_mm) or focal_depth_mm < 0:
        raise PhysicsDomainError("INVALID_FOCAL_DEPTH", "Focal depth must be non-negative.")
    index = float(sellmeier_index(wavelength_um))
    group_index = float(sellmeier_group_index(wavelength_um))
    factor = float(
        np.tan(np.arcsin(numerical_aperture))
        / np.tan(np.arcsin(numerical_aperture / index))
    )
    stretch = focal_depth_mm * 1000.0 * max(0.0, factor - index)
    lateral = 0.61 * wavelength_um / numerical_aperture
    diffraction_axial = 2.0 * index * wavelength_um / numerical_aperture**2
    axial = float(np.hypot(diffraction_axial, stretch))
    geometry = VoxelGeometry(
        lateral_fwhm_um=float(lateral),
        diffraction_axial_fwhm_um=float(diffraction_axial),
        spherical_aberration_stretch_um=float(stretch),
        axial_fwhm_um=axial,
        aspect_ratio=float(axial / lateral),
    )
    return AberrationResult(
        index=index,
        group_index=group_index,
        group_velocity_m_s=SPEED_OF_LIGHT_M_S / group_index,
        marginal_focus_factor=factor,
        axial_energy_density_ratio=min(1.0, diffraction_axial / axial),
        geometry=geometry,
    )


def gaussian_peak_intensity_tw_cm2(
    pulse_energy_nj: float,
    pulse_duration_fs: float,
    wavelength_um: float,
    numerical_aperture: float,
) -> float:
    if pulse_energy_nj <= 0 or pulse_duration_fs <= 0:
        raise PhysicsDomainError("INVALID_PULSE", "Pulse energy and duration must be positive.")
    waist_m = 0.61 * wavelength_um * 1e-6 / numerical_aperture
    intensity_w_m2 = (
        2.0 * pulse_energy_nj * 1e-9
        / (np.pi * waist_m**2 * pulse_duration_fs * 1e-15)
    )
    return float(intensity_w_m2 / 1e16)


def simulate_write(
    *,
    data_size_bytes: int,
    numerical_aperture: float,
    focal_depth_mm: float,
    wavelength_um: float,
    pulse_energy_nj: float,
    pulse_duration_fs: float = 300.0,
    temperature_k: float,
    type_ii_threshold_tw_cm2: float = DEFAULT_TYPE_II_THRESHOLD_TW_CM2,
    repetition_rate_hz: float = DEFAULT_REPETITION_RATE_HZ,
    bits_per_voxel: int = 8,
) -> dict[str, Any]:
    aberration = spherical_aberration(wavelength_um, numerical_aperture, focal_depth_mm)
    ideal_peak = gaussian_peak_intensity_tw_cm2(
        pulse_energy_nj, pulse_duration_fs, wavelength_um, numerical_aperture
    )
    effective_peak = ideal_peak * aberration.axial_energy_density_ratio
    type_ii = effective_peak >= type_ii_threshold_tw_cm2
    retention = arrhenius_retention(temperature_k) if type_ii else type_i_retention_policy()
    voxels = ceil(data_size_bytes * 8 / bits_per_voxel)
    warnings = [
        "The Type II lifetime is an Arrhenius extrapolation from accelerated aging, not a direct long-duration measurement."
    ]
    if not type_ii:
        warnings.append(
            "Peak intensity is below the configured Type II threshold; retention uses the Type I engineering fallback."
        )
    if focal_depth_mm > 0:
        warnings.append(
            "The aberration model is a scalar planar-interface approximation, not a vectorial full-wave solver."
        )
    return {
        "physical_valid": type_ii,
        "write_regime": "type_ii_nanograting" if type_ii else "type_i_fallback",
        "threshold": {
            "type_ii_achieved": type_ii,
            "configured_threshold_tw_cm2": type_ii_threshold_tw_cm2,
            "ideal_peak_intensity_tw_cm2": ideal_peak,
            "effective_peak_intensity_tw_cm2": effective_peak,
            "aberration_intensity_multiplier": aberration.axial_energy_density_ratio,
        },
        "dispersion": {
            "refractive_index": aberration.index,
            "group_index": aberration.group_index,
            "group_velocity_m_s": aberration.group_velocity_m_s,
        },
        "retention": asdict(retention),
        "voxel": asdict(aberration.geometry),
        "write_plan": {
            "data_size_bytes": data_size_bytes,
            "bits_per_voxel": bits_per_voxel,
            "voxels_required": voxels,
            "repetition_rate_hz": repetition_rate_hz,
            "idealized_write_time_s": voxels / repetition_rate_hz,
        },
        "model_scope": {
            "material": "fused_silica",
            "sellmeier_range_um": [SELLMEIER_MIN_UM, SELLMEIER_MAX_UM],
            "temperature_reference_for_index_c": 20.0,
            "aberration_model": "geometric_planar_interface_plus_diffraction",
        },
        "warnings": warnings,
    }

