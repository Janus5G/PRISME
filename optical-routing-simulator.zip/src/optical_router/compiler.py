"""Spectral-state quantization, bit packing, and OPTB v1 serialization."""

from __future__ import annotations

from dataclasses import dataclass
from math import ceil, log2
import struct
import zlib

import numpy as np
from numpy.typing import NDArray

from .constants import SPEED_OF_LIGHT_M_S
from .errors import PhysicsDomainError
from .physics import sellmeier_group_index

MAGIC = b"OPTB"
FORMAT_VERSION = 1
FLAG_MSB_FIRST = 1
FLAG_SELF_DESCRIBING_MAPPING = 2
FIXED_HEADER = struct.Struct("<4sBBHIIQBBBBHHHII")


@dataclass(frozen=True, slots=True)
class MappingTable:
    wavelength_bins_um: tuple[float, ...]
    polarization_bins_deg: tuple[float, ...]
    intensity_bins: tuple[float, ...]
    max_wavelength_error_nm: float = 10.0


@dataclass(frozen=True, slots=True)
class CompiledStream:
    content: bytes
    symbol_count: int
    bits_per_symbol: int
    payload_bytes: int
    crc32: int
    rows: int
    columns: int
    quantization: dict[str, float]


@dataclass(frozen=True, slots=True)
class StreamTiming:
    propagation_latency_ns: float
    dispersion_skew_ps: float
    sensor_conversion_ns: float
    serialization_ns: float
    total_pipeline_latency_ns: float
    payload_throughput_gbps: float
    bottleneck: str


def _bits_required(count: int) -> int:
    return max(1, ceil(log2(count)))


def _bins(values: tuple[float, ...], name: str) -> NDArray[np.float64]:
    array = np.asarray(values, dtype=np.float64)
    if array.ndim != 1 or array.size < 2:
        raise PhysicsDomainError("INVALID_MAPPING", f"{name} needs at least two bins.")
    if not np.all(np.isfinite(array)) or np.any(np.diff(array) <= 0):
        raise PhysicsDomainError("INVALID_MAPPING", f"{name} must be finite and ascending.")
    return array


def _nearest(
    values: NDArray[np.float64], bins: NDArray[np.float64]
) -> tuple[NDArray[np.uint64], NDArray[np.float64]]:
    insertion = np.searchsorted(bins, values, side="left")
    right = np.clip(insertion, 0, bins.size - 1)
    left = np.clip(insertion - 1, 0, bins.size - 1)
    choose_right = np.abs(values - bins[right]) < np.abs(values - bins[left])
    index = np.where(choose_right, right, left)
    return index.astype(np.uint64), np.abs(values - bins[index])


def compile_color_matrix(
    wavelengths_um: NDArray[np.float64],
    polarizations_deg: NDArray[np.float64],
    intensities: NDArray[np.float64],
    mapping: MappingTable,
) -> CompiledStream:
    """Compile rectangular arrays into a deterministic, self-describing binary."""

    if wavelengths_um.ndim != 2 or wavelengths_um.size == 0:
        raise PhysicsDomainError("INVALID_COLOR_MATRIX", "Matrix must be non-empty and 2D.")
    if polarizations_deg.shape != wavelengths_um.shape or intensities.shape != wavelengths_um.shape:
        raise PhysicsDomainError("INVALID_COLOR_MATRIX", "All state arrays must have equal shape.")
    if not np.all(np.isfinite(polarizations_deg)) or not np.all(np.isfinite(intensities)):
        raise PhysicsDomainError("NONFINITE_COLOR_STATE", "All state values must be finite.")
    if np.any((polarizations_deg < 0) | (polarizations_deg >= 180)):
        raise PhysicsDomainError("INVALID_POLARIZATION", "Polarization must be in [0, 180).")
    if np.any((intensities < 0) | (intensities > 1)):
        raise PhysicsDomainError("INVALID_INTENSITY", "Intensity must be in [0, 1].")

    sellmeier_group_index(wavelengths_um)  # validates the silica spectral domain
    w_bins = _bins(mapping.wavelength_bins_um, "wavelength_bins_um")
    p_bins = _bins(mapping.polarization_bins_deg, "polarization_bins_deg")
    i_bins = _bins(mapping.intensity_bins, "intensity_bins")
    w_idx, w_error = _nearest(wavelengths_um, w_bins)
    p_idx, p_error = _nearest(polarizations_deg, p_bins)
    i_idx, i_error = _nearest(intensities, i_bins)
    max_wavelength_error_nm = float(np.max(w_error) * 1000)
    if max_wavelength_error_nm > mapping.max_wavelength_error_nm:
        raise PhysicsDomainError(
            "WAVELENGTH_QUANTIZATION_ERROR",
            f"Nearest channel is {max_wavelength_error_nm:.3f} nm away; allowed maximum is {mapping.max_wavelength_error_nm:.3f} nm.",
            context={
                "maximum_error_nm": max_wavelength_error_nm,
                "allowed_error_nm": mapping.max_wavelength_error_nm,
            },
        )

    w_bits, p_bits, i_bits = map(
        _bits_required, (w_bins.size, p_bins.size, i_bins.size)
    )
    bits_per_symbol = w_bits + p_bits + i_bits
    if bits_per_symbol > 63:
        raise PhysicsDomainError("MAPPING_TOO_LARGE", "Mapping exceeds 63 bits per symbol.")
    symbols = (
        (w_idx << np.uint64(p_bits + i_bits))
        | (p_idx << np.uint64(i_bits))
        | i_idx
    ).reshape(-1)
    shifts = np.arange(bits_per_symbol - 1, -1, -1, dtype=np.uint64)
    bits = ((symbols[:, None] >> shifts) & 1).astype(np.uint8)
    payload = np.packbits(bits.reshape(-1), bitorder="big").tobytes()
    crc32 = zlib.crc32(payload) & 0xFFFFFFFF
    mapping_bytes = b"".join(
        (
            w_bins.astype("<f4", copy=False).tobytes(),
            p_bins.astype("<f4", copy=False).tobytes(),
            i_bins.astype("<f4", copy=False).tobytes(),
        )
    )
    header_size = FIXED_HEADER.size + len(mapping_bytes)
    if header_size > 0xFFFF:
        raise PhysicsDomainError("MAPPING_TOO_LARGE", "Serialized mapping exceeds 65,535 bytes.")
    rows, columns = wavelengths_um.shape
    header = FIXED_HEADER.pack(
        MAGIC,
        FORMAT_VERSION,
        FLAG_MSB_FIRST | FLAG_SELF_DESCRIBING_MAPPING,
        header_size,
        rows,
        columns,
        symbols.size,
        w_bits,
        p_bits,
        i_bits,
        bits_per_symbol,
        w_bins.size,
        p_bins.size,
        i_bins.size,
        len(payload),
        crc32,
    )
    return CompiledStream(
        content=header + mapping_bytes + payload,
        symbol_count=int(symbols.size),
        bits_per_symbol=bits_per_symbol,
        payload_bytes=len(payload),
        crc32=crc32,
        rows=rows,
        columns=columns,
        quantization={
            "max_wavelength_error_nm": max_wavelength_error_nm,
            "max_polarization_error_deg": float(np.max(p_error)),
            "max_intensity_error": float(np.max(i_error)),
        },
    )


def inspect_binary(content: bytes) -> dict[str, object]:
    """Validate and inspect an OPTB v1 stream without decoding user data."""

    if len(content) < FIXED_HEADER.size:
        raise PhysicsDomainError("TRUNCATED_BINARY", "Binary header is truncated.")
    fields = FIXED_HEADER.unpack_from(content)
    (
        magic, version, flags, header_size, rows, columns, symbol_count,
        w_bits, p_bits, i_bits, symbol_bits, w_count, p_count, i_count,
        payload_size, expected_crc,
    ) = fields
    if magic != MAGIC or version != FORMAT_VERSION:
        raise PhysicsDomainError("UNSUPPORTED_BINARY", "Not a supported OPTB v1 stream.")
    mapping_bytes = 4 * (w_count + p_count + i_count)
    if header_size != FIXED_HEADER.size + mapping_bytes:
        raise PhysicsDomainError("INVALID_BINARY_HEADER", "Mapping size does not match the header.")
    if len(content) != header_size + payload_size:
        raise PhysicsDomainError("TRUNCATED_BINARY", "Payload length does not match the header.")
    payload = content[header_size:]
    actual_crc = zlib.crc32(payload) & 0xFFFFFFFF
    if actual_crc != expected_crc:
        raise PhysicsDomainError("CRC_MISMATCH", "Payload CRC32 check failed.")
    mapping = np.frombuffer(
        content, dtype="<f4", count=mapping_bytes // 4, offset=FIXED_HEADER.size
    )
    w_end, p_end = w_count, w_count + p_count
    return {
        "version": version,
        "flags": flags,
        "header_size": header_size,
        "rows": rows,
        "columns": columns,
        "symbol_count": symbol_count,
        "bits": {
            "wavelength": w_bits,
            "polarization": p_bits,
            "intensity": i_bits,
            "symbol": symbol_bits,
        },
        "mapping": {
            "wavelength_bins_um": mapping[:w_end].astype(float).tolist(),
            "polarization_bins_deg": mapping[w_end:p_end].astype(float).tolist(),
            "intensity_bins": mapping[p_end:].astype(float).tolist(),
        },
        "payload_size": payload_size,
        "crc32": actual_crc,
    }


def simulate_stream_timing(
    *,
    wavelengths_um: NDArray[np.float64],
    symbol_count: int,
    payload_bytes: int,
    fiber_length_m: float,
    free_space_distance_m: float,
    sensor_sample_rate_gsps: float,
    sensor_channels: int,
    memory_bandwidth_gbps: float,
) -> StreamTiming:
    group_indices = sellmeier_group_index(wavelengths_um.reshape(-1))
    propagation_s = (
        free_space_distance_m / SPEED_OF_LIGHT_M_S
        + fiber_length_m * float(np.mean(group_indices)) / SPEED_OF_LIGHT_M_S
    )
    skew_s = (
        fiber_length_m
        * float(np.max(group_indices) - np.min(group_indices))
        / SPEED_OF_LIGHT_M_S
    )
    sensor_s = symbol_count / (sensor_sample_rate_gsps * 1e9 * sensor_channels)
    serialization_s = payload_bytes / (memory_bandwidth_gbps * 1e9 / 8)
    conversion_s = max(sensor_s, serialization_s)
    return StreamTiming(
        propagation_latency_ns=propagation_s * 1e9,
        dispersion_skew_ps=skew_s * 1e12,
        sensor_conversion_ns=sensor_s * 1e9,
        serialization_ns=serialization_s * 1e9,
        total_pipeline_latency_ns=(propagation_s + conversion_s) * 1e9,
        payload_throughput_gbps=(
            payload_bytes * 8 / conversion_s / 1e9 if conversion_s else 0.0
        ),
        bottleneck="sensor_array" if sensor_s >= serialization_s else "serializer",
    )

