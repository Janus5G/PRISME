from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class WriteSimulationRequest(StrictModel):
    data_size_bytes: int = Field(ge=0, le=10**15)
    numerical_aperture: float = Field(gt=0, lt=1)
    focal_depth_mm: float = Field(ge=0, le=100)
    wavelength_um: float
    pulse_energy_nj: float = Field(gt=0, le=10**9)
    temperature_k: float = Field(gt=0, le=5000)
    pulse_duration_fs: float = Field(default=300, gt=0, le=10**9)
    type_ii_threshold_tw_cm2: float = Field(default=10, gt=0, le=10**9)
    repetition_rate_hz: float = Field(default=200_000, gt=0, le=10**12)
    bits_per_voxel: int = Field(default=8, ge=1, le=64)


class ColorState(StrictModel):
    wavelength_um: float
    polarization_deg: float = Field(ge=0, lt=180)
    intensity: float = Field(ge=0, le=1)


class SpectralMappingRequest(StrictModel):
    wavelength_bins_um: list[float] = Field(
        default_factory=lambda: [0.405, 0.450, 0.488, 0.532, 0.650, 0.780, 1.064, 1.550],
        min_length=2,
        max_length=1024,
    )
    polarization_bins_deg: list[float] = Field(
        default_factory=lambda: [0, 45, 90, 135], min_length=2, max_length=1024
    )
    intensity_bins: list[float] = Field(
        default_factory=lambda: [0.125, 0.375, 0.625, 0.875],
        min_length=2,
        max_length=1024,
    )
    max_wavelength_error_nm: float = Field(default=10, ge=0, le=10_000)

    @field_validator("wavelength_bins_um", "polarization_bins_deg", "intensity_bins")
    @classmethod
    def ascending(cls, values: list[float]) -> list[float]:
        if any(b <= a for a, b in zip(values, values[1:])):
            raise ValueError("bins must be unique and strictly ascending")
        return values

    @field_validator("polarization_bins_deg")
    @classmethod
    def polarization_domain(cls, values: list[float]) -> list[float]:
        if values[0] < 0 or values[-1] >= 180:
            raise ValueError("polarization bins must be in [0, 180)")
        return values

    @field_validator("intensity_bins")
    @classmethod
    def intensity_domain(cls, values: list[float]) -> list[float]:
        if values[0] < 0 or values[-1] > 1:
            raise ValueError("intensity bins must be in [0, 1]")
        return values


class StreamSimulationRequest(StrictModel):
    matrix: list[list[ColorState]] = Field(min_length=1)
    mapping: SpectralMappingRequest = Field(default_factory=SpectralMappingRequest)
    fiber_length_m: float = Field(default=100, ge=0, le=10**9)
    free_space_distance_m: float = Field(default=1, ge=0, le=10**6)
    sensor_sample_rate_gsps: float = Field(default=20, gt=0, le=10**6)
    sensor_channels: int = Field(default=64, ge=1, le=10**9)
    memory_bandwidth_gbps: float = Field(default=160, gt=0, le=10**9)
    output_filename: str = Field(default="optical-stream.bin", min_length=1, max_length=128)

    @model_validator(mode="after")
    def rectangular(self) -> "StreamSimulationRequest":
        width = len(self.matrix[0])
        if width == 0 or any(len(row) != width for row in self.matrix):
            raise ValueError("matrix must be non-empty and rectangular")
        return self

