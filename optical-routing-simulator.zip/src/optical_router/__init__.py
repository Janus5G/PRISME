"""Optical routing simulator package."""

from .api import app, create_app

__all__ = ["app", "create_app"]
__version__ = "0.1.0"

